import { t as __commonJSMin } from "../_runtime.mjs";
import { a as require_token_error, i as require_token_util } from "./@ai-sdk/gateway+[...].mjs";
//#region node_modules/@vercel/oidc/dist/token.js
var require_token = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var __defProp = Object.defineProperty;
	var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
	var __getOwnPropNames = Object.getOwnPropertyNames;
	var __hasOwnProp = Object.prototype.hasOwnProperty;
	var __export = (target, all) => {
		for (var name in all) __defProp(target, name, {
			get: all[name],
			enumerable: true
		});
	};
	var __copyProps = (to, from, except, desc) => {
		if (from && typeof from === "object" || typeof from === "function") {
			for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
				get: () => from[key],
				enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
			});
		}
		return to;
	};
	var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
	var token_exports = {};
	__export(token_exports, { refreshToken: () => refreshToken });
	module.exports = __toCommonJS(token_exports);
	var import_token_error = require_token_error();
	var import_token_util = require_token_util();
	async function refreshToken(options) {
		let projectId = options?.project;
		let teamId = options?.team;
		if (!projectId && !teamId) {
			const projectInfo = (0, import_token_util.findProjectInfo)();
			projectId = projectInfo.projectId;
			teamId = projectInfo.teamId;
		} else if (!projectId || !teamId) {
			const projectInfo = (0, import_token_util.findProjectInfo)();
			projectId = projectId ?? projectInfo.projectId;
			teamId = teamId ?? projectInfo.teamId;
		}
		if (!projectId) throw new import_token_error.VercelOidcTokenError("Failed to refresh OIDC token: No project specified. Try re-linking your project with `vc link`");
		let maybeToken = (0, import_token_util.loadToken)(projectId);
		if (!maybeToken || (0, import_token_util.isExpired)((0, import_token_util.getTokenPayload)(maybeToken.token), options?.expirationBufferMs)) {
			const authToken = await (0, import_token_util.getVercelToken)({ expirationBufferMs: options?.expirationBufferMs });
			maybeToken = await (0, import_token_util.getVercelOidcToken)(authToken, projectId, teamId);
			if (!maybeToken) throw new import_token_error.VercelOidcTokenError("Failed to refresh OIDC token");
			(0, import_token_util.saveToken)(maybeToken, projectId);
		}
		process.env.VERCEL_OIDC_TOKEN = maybeToken.token;
	}
	0 && (module.exports = { refreshToken });
}));
//#endregion
export { require_token as t };
